
public interface Pair_ {
	public String f();
	public String l();
	public String toString();
}
