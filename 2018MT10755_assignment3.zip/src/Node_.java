
public interface Node_<K,T> {
	public Node_ getLeft();
	public Node_ getRight();
	public K getKey();
	public T getObj();
}
